<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">APLIKASI</h4>
                </div>
                <div class="card-body">
                    <div class="row row-cards">
                        <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-lg-3">
                                <a href="<?php echo e($app->url); ?>?token=<?php echo e($token); ?>" class="text-decoration-none"
                                    target="_blank">
                                    <div class="card card-sm">
                                        <div class="card-body">
                                            <div class="row align-items-center">
                                                <div class="col-auto">
                                                    <?php if($app->type_icon === 'svg'): ?>
                                                        <span
                                                            class="bg-danger text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/currency-dollar -->
                                                            <?php echo $app->icon; ?>

                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if($app->type_icon === 'url_img'): ?>
                                                        <img src="<?php echo e($app->icon); ?>" alt="<?php echo e($app->name); ?>"
                                                            class="img img-fluid">
                                                    <?php endif; ?>
                                                    <?php if($app->type_icon === 'upload_img'): ?>
                                                        <img src="/storage/<?php echo e($app->icon); ?>" alt="<?php echo e($app->name); ?>"
                                                            class="img img-fluid">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="col">
                                                    <div class="font-weight-medium">
                                                        Sertifikat Dokter PPPDS
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        setTimeout(() => {
            location.reload()
        }, 15000);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sso-fkuh\resources\views/dashboard.blade.php ENDPATH**/ ?>