
<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4 class="card-title">Edit Application</h4>
                </div>
                <div class="card-body">
                    <form action="/apps/<?php echo e($app->id); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="" class="form-label">Nama <span class="text-danger">*</span></label>
                            <input type="text" placeholder="...." class="form-control" name="name" required
                                value="<?php echo e($app->name); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"> <?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">URL <span class="text-danger">*</span></label>
                            <input type="text" placeholder="...." class="form-control" required name="url"
                                value="<?php echo e($app->url); ?>">
                            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"> <?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Type Icon</label>
                            <select name="type_icon" id="type_icon" class="form-select">
                                <option value="">Pilih</option>
                                <option value="svg">SVG</option>
                                <option value="url_img">URL Image</option>
                                <option value="upload_img">Upload Image</option>
                            </select>
                            <?php $__errorArgs = ['type_icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"> <?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3" id="icon">

                        </div>
                        <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"> <?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#type_icon').val("<?php echo e($app->type_icon); ?>").change()
        })
        $('#type_icon').on('change', function() {
            let val = $('#type_icon').val()
            if (val === '') {
                $('#icon').html(``)
            }
            var iconValue = "<?php echo e($app->icon); ?>"
            if (val === 'svg') {
                $('#icon').html(` <label for="" class="form-label">Icon SVG </label>
                            <textarea name="icon" id="icon" rows="10" class="form-control h-100">${iconValue}</textarea>
                            `)
            }

            if (val === 'url_img') {
                $('#icon').html(
                    `   <label for="" class="form-label">URL Image</label>
                            <input type="text" value="${iconValue}" class="form-control" name="icon" placeholder="https://....">`
                    )
            }

            if (val === 'upload_img') {
                $('#icon').html(
                    `   <label for="" class="form-label">File Image</label>
                            <input type="file" class="form-control" accept="image/*" name="icon" placeholder="https://....">`
                )
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sso-fkuh\resources\views/adminsso/apps/edit.blade.php ENDPATH**/ ?>