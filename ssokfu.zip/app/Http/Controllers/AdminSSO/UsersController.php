<?php

namespace App\Http\Controllers\AdminSSO;

use App\Http\Controllers\Controller;
use App\Imports\UsersImport;
use App\Models\User;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class UsersController extends Controller
{
    public function index()
    {
        $users = User::role(['adminsso', 'admin', 'mahasiswa', 'dosen'])->get();
        return view('adminsso.users.index', compact('users'));
    }

    public function import(Request $request)
    {
        $request->validate([
            'file' => ['file', 'mimes:xlsx', 'required'],
        ]);
        Excel::import(new UsersImport, $request->file('file'));
        return redirect('/dashboard')->with('success', 'All good!');
    }
}
