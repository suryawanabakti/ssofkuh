<?php

use App\Http\Controllers\AdminSSO\UsersController;
use App\Http\Controllers\ProfileController;
use App\Imports\UsersImport;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Maatwebsite\Excel\Facades\Excel;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});


Route::get('/dashboard', function () {
    $token = (string) str()->uuid();
    User::find(auth()->id())->update([
        'token' => $token
    ]);
    return view('dashboard', compact('token'));
})->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/users', [UsersController::class, 'index'])->middleware(['auth', 'verified'])->name('users');
Route::post('/users/import', [UsersController::class, 'import']);

Route::get('/login-sso', function () {
    $user =  User::where('token', request('token'))->first();
    if (empty($user)) {
        return response()->json([
            'message' => "Token tidak ditemukan"
        ], 404);
    }

    return $user;
})->middleware('ssoauth');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});



require __DIR__ . '/auth.php';
